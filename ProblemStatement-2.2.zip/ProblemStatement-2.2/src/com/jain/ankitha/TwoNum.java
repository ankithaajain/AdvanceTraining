package com.jain.ankitha;

class TwoNum {
	  public static void main(String[] args) {

	    int i = 1, n = 13, firstTerm = 1, secondTerm = 3;
	    System.out.println("Java Problem " + " 2 1 3:");

	    while (i <= n) {
	      System.out.print(firstTerm + ", ");

	      int nextTerm = firstTerm + secondTerm;
	      firstTerm = secondTerm;
	      secondTerm = nextTerm;

	      i++;
	    }
	  }
	}

