package com.jain.ankitha;

public abstract class Instrument {
	public abstract void play();
}
